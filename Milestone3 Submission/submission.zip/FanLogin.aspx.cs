﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.Http.Results;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Milestone_Three
{
    public partial class FanLogIn : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            Session["Username"] = txtUserName.Text;

            string connStr = WebConfigurationManager.ConnectionStrings["Milestone"].ToString();
            SqlConnection con = new SqlConnection(connStr);

            /*            System Admin Login            */

            SqlCommand cmd = new SqlCommand("select * from System_Admin where UserName =@username and Password=@password", con);          
            cmd.Parameters.AddWithValue("@username", txtUserName.Text);
            cmd.Parameters.AddWithValue("@password", txtPWD.Text);

            con.Open();

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            /*       Sports Association Manager Login                     */

            SqlCommand cmd2 = new SqlCommand("select * from Sports_Association_Manager where UserName =@username and Password=@password", con);
            cmd2.Parameters.AddWithValue("@username", txtUserName.Text);
            cmd2.Parameters.AddWithValue("@password", txtPWD.Text);
            SqlDataAdapter da2 = new SqlDataAdapter(cmd2);
            DataTable dt2 = new DataTable();
            da2.Fill(dt2);

            /*     Club Representative Login                     */

            SqlCommand cmd3 = new SqlCommand("select * from Club_Representative where UserName =@username and Password=@password", con);
            cmd3.Parameters.AddWithValue("@username", txtUserName.Text);
            cmd3.Parameters.AddWithValue("@password", txtPWD.Text);
            SqlDataAdapter da3 = new SqlDataAdapter(cmd3);
            DataTable dt3 = new DataTable();
            da3.Fill(dt3);

            /*     Stadium Manager Login                    */

            SqlCommand cmd4 = new SqlCommand("select * from Stadium_Manager where UserName =@username and Password=@password", con);
            cmd4.Parameters.AddWithValue("@username", txtUserName.Text);
            cmd4.Parameters.AddWithValue("@password", txtPWD.Text);
            SqlDataAdapter da4 = new SqlDataAdapter(cmd4);
            DataTable dt4 = new DataTable();
            da4.Fill(dt4);


            /*           Fan Login                    */

            SqlCommand cmd5 = new SqlCommand("select * from Fan where UserName =@username and Password=@password", con);
            cmd5.Parameters.AddWithValue("@username", txtUserName.Text);
            cmd5.Parameters.AddWithValue("@password", txtPWD.Text);
            SqlDataAdapter da5 = new SqlDataAdapter(cmd5);
            DataTable dt5 = new DataTable();
            da5.Fill(dt5);














            if (dt.Rows.Count > 0)
            {
                Response.Redirect("/SystemAdmin.aspx");

            }
            else if  (dt2.Rows.Count > 0)
            {
                Response.Redirect("/AssMngAccess.aspx");

            }
            else if (dt3.Rows.Count > 0)
            {
                Response.Redirect("/ClubRepresentativeAccess.aspx");
            }
            else if (dt4.Rows.Count > 0)
            {
                Response.Redirect("/StadiumMngAccess.aspx");
            }
            else if(dt5.Rows.Count > 0 )
            {
                Response.Redirect("/FanAccess.aspx");
            }
            else
            {

                error.Text = "User is not registered" ;

            }



































            con.Close();










        }

        protected void SignUp_Click(object sender, EventArgs e)
        {
            Response.Redirect("/Home.aspx");
        }
    }
}