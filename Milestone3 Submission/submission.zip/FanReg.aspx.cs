﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Milestone_Three
{
    public partial class FanLoginIn : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnsubmit_Click(object sender, EventArgs e)
        {
            string connStr = WebConfigurationManager.ConnectionStrings["MILESTONE"].ToString();
            SqlConnection conn = new SqlConnection(connStr);

            string name = TextBox2.Text;
            string username = txtuser.Text;
            string password = txtpwd.Text;
            string cnpassword = txtcnmpwd.Text;
            string nationalID = TextBox1.Text;
            int phone = Int32.Parse(TextBox3.Text);
            DateTime DOB = Convert.ToDateTime(TextBox4.Text);
            string address = txtfname.Text;
            
            SqlCommand fanreg = new SqlCommand("addFan", conn);

            fanreg.CommandType = System.Data.CommandType.StoredProcedure;

            fanreg.Parameters.Add(new SqlParameter("@name", name));
            fanreg.Parameters.Add(new SqlParameter("@username", username));
            fanreg.Parameters.Add(new SqlParameter("@password", password));
            fanreg.Parameters.Add(new SqlParameter("@national_id", nationalID));
            fanreg.Parameters.Add(new SqlParameter("@birth_date", DOB));
            fanreg.Parameters.Add(new SqlParameter("@address", address));
            fanreg.Parameters.Add(new SqlParameter("@phonenumber", phone));

            conn.Open();

            /* Association Manager*/

            SqlCommand AssociationManagerCommand = new SqlCommand("Select * from allAssocManagers where UserName = @username", conn);
            AssociationManagerCommand.Parameters.AddWithValue("@username", username);
            SqlDataAdapter da = new SqlDataAdapter(AssociationManagerCommand);
            DataTable AssociatinManagerTable = new DataTable();
            da.Fill(AssociatinManagerTable);


            /*ClubRepresentative*/

            SqlCommand ClubRepresentativeCommand = new SqlCommand("Select * from allClubRepresentatives where UserName = @username", conn);
            ClubRepresentativeCommand.Parameters.AddWithValue("@username", username);
            SqlDataAdapter da2 = new SqlDataAdapter(AssociationManagerCommand);
            DataTable ClubRepresentativeTable = new DataTable();
            da2.Fill(ClubRepresentativeTable);

            /*System Admin*/

            SqlCommand SystemAdminCommand = new SqlCommand("Select * from allSystemAdmins where UserName = @username", conn);
            SystemAdminCommand.Parameters.AddWithValue("@username", username);
            SqlDataAdapter da3 = new SqlDataAdapter(SystemAdminCommand);
            DataTable SystemAdminTable = new DataTable();
            da3.Fill(SystemAdminTable);



            /* Stadium Manager*/

            SqlCommand StadiumManagerCommand = new SqlCommand("Select * from allStadiumManagers where UserName = @username", conn);
            StadiumManagerCommand.Parameters.AddWithValue("@username", username);
            SqlDataAdapter da4 = new SqlDataAdapter(StadiumManagerCommand);
            DataTable StadiumManagerTable = new DataTable();
            da4.Fill(StadiumManagerTable);


            /*Fan*/

            SqlCommand FanCommand = new SqlCommand("Select * from allFans where UserName = @username", conn);
            FanCommand.Parameters.AddWithValue("@username", username);
            SqlDataAdapter da5 = new SqlDataAdapter(StadiumManagerCommand);
            DataTable FanTable = new DataTable();
            da5.Fill(FanTable);




            if ((AssociatinManagerTable.Rows.Count > 0) || (ClubRepresentativeTable.Rows.Count > 0) || (SystemAdminTable.Rows.Count > 0) || (StadiumManagerTable.Rows.Count > 0) || (FanTable.Rows.Count > 0))
            {
                lblErrorMsg.Text = "username already registered";
            }

            else
            {
                fanreg.ExecuteNonQuery();
            }
            conn.Close();
        }

        protected void Login_Click(object sender, EventArgs e)
        {
            Response.Redirect("/FanLogin.aspx");
        }
    }
}