﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.Services.Description;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Milestone_Three
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnsubmit_Click(object sender, EventArgs e)
        {
            
                string UserName = txtuser.Text;
                string Password = txtpwd.Text;
                string Name = txtfname.Text;
                string connStr = WebConfigurationManager.ConnectionStrings["Milestone"].ToString();
                SqlConnection con = new SqlConnection(connStr);
               
                SqlCommand cmd = new SqlCommand("addAssociationManager", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@name", Name);
                cmd.Parameters.AddWithValue("@username", UserName);
                cmd.Parameters.AddWithValue("@password", Password);
                con.Open();

           /* Association Manager*/

            SqlCommand AssociationManagerCommand = new SqlCommand("Select * from allAssocManagers where UserName = @username",con);
            AssociationManagerCommand.Parameters.AddWithValue("@username", UserName);
            SqlDataAdapter da = new SqlDataAdapter(AssociationManagerCommand);
            DataTable AssociatinManagerTable = new DataTable();
            da.Fill(AssociatinManagerTable);
            

            /*ClubRepresentative*/

            SqlCommand ClubRepresentativeCommand = new SqlCommand("Select * from allClubRepresentatives where UserName = @username", con);
            ClubRepresentativeCommand.Parameters.AddWithValue("@username", UserName);
            SqlDataAdapter da2 = new SqlDataAdapter(AssociationManagerCommand);
            DataTable ClubRepresentativeTable = new DataTable();
            da2.Fill(ClubRepresentativeTable);
        
            /*System Admin*/

            SqlCommand SystemAdminCommand = new SqlCommand("Select * from allSystemAdmins where UserName = @username", con);
            SystemAdminCommand.Parameters.AddWithValue("@username", UserName);
            SqlDataAdapter da3 = new SqlDataAdapter(SystemAdminCommand);
            DataTable SystemAdminTable = new DataTable();
            da3.Fill(SystemAdminTable);
           


            /* Stadium Manager*/

            SqlCommand StadiumManagerCommand = new SqlCommand("Select * from allStadiumManagers where UserName = @username", con);
            StadiumManagerCommand.Parameters.AddWithValue("@username", UserName);
            SqlDataAdapter da4 = new SqlDataAdapter(StadiumManagerCommand);
            DataTable StadiumManagerTable = new DataTable();
            da4.Fill(StadiumManagerTable);
            

            /*Fan*/

            SqlCommand FanCommand = new SqlCommand("Select * from allFans where UserName = @username", con);
            FanCommand.Parameters.AddWithValue("@username", UserName);
            SqlDataAdapter da5 = new SqlDataAdapter(StadiumManagerCommand);
            DataTable FanTable = new DataTable();
            da5.Fill(FanTable);
 



            if ( (AssociatinManagerTable.Rows.Count > 0)  || (ClubRepresentativeTable.Rows.Count > 0) ||  (SystemAdminTable.Rows.Count > 0) || (StadiumManagerTable.Rows.Count > 0) || (FanTable.Rows.Count > 0))
            {
                lblErrorMsg.Text = "username already registered";
            }

            else
            {
                cmd.ExecuteNonQuery();
            }

            con.Close();



        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            Response.Redirect("/FanLogin.aspx");
        }
    }
}