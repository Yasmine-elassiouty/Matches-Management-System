﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Milestone_Three
{
    public partial class ClubRepresentativeAccess : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        protected void home_Click(object sender, EventArgs e)
        {
            MultiView2.ActiveViewIndex = -1;
        }


        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            MultiView2.ActiveViewIndex = 0;
            GridView2.DataBind();
        }

        protected void stdms_Click(object sender, EventArgs e)
        {

            MultiView2.ActiveViewIndex = 1;
        }

        protected void SubmitDate_Click(object sender, EventArgs e)
        {
            /*DateTime inpDate = Convert.ToDateTime(TextBox1.Text);
            string connStr = WebConfigurationManager.ConnectionStrings["MILESTONE"].ToString();
            SqlConnection conn = new SqlConnection(connStr);
            SqlCommand command = new SqlCommand("SELECT * from viewAvailableStadiumsOn(@datetime)", conn);
            command.Parameters.AddWithValue("@datetime", inpDate);

            conn.Open();
            SqlDataReader rdr = command.ExecuteReader(CommandBehavior.CloseConnection);
            while (rdr.Read())
            {
                string Name = rdr.GetString(rdr.GetOrdinal("stadiumname"));
                string Location = rdr.GetString(rdr.GetOrdinal("stadiumlocation"));
                int stadiumCapacity = rdr.GetInt32(rdr.GetOrdinal("stadiumcapacity"));
                TableRow row = new TableRow();
                TableCell cell1 = new TableCell();
                TableCell cell2 = new TableCell();
                TableCell cell3 = new TableCell();
                cell1.Text = Name;
                cell2.Text = Location;
                cell3.Text = stadiumCapacity + "";
                row.Cells.Add(cell1);
                row.Cells.Add(cell2);
                row.Cells.Add(cell3);
                Table1.Rows.Add(row);
            }*/
            DateTime inpDate = Convert.ToDateTime(TextBox1.Text);

            string connStr = WebConfigurationManager.ConnectionStrings["MILESTONE"].ToString();
            SqlConnection con = new SqlConnection(connStr);
            SqlCommand command = new SqlCommand("SELECT * from viewAvailableStadiumsOn(@datetime)", con);
            command.Parameters.AddWithValue("@datetime", inpDate);
            con.Open();
            SqlDataAdapter da2 = new SqlDataAdapter(command);
            DataTable dt2 = new DataTable();
            da2.Fill(dt2);

            GridView4.DataSource = dt2;
            GridView4.DataBind();
        }

   
        


        protected void Matches_Click(object sender, EventArgs e)
        {
            MultiView2.ActiveViewIndex = 2;
            this.BindGrid1();
            GridView1.DataBind();    
            
            
        }

        private void BindGrid1()
        {

            string connStr = WebConfigurationManager.ConnectionStrings["MILESTONE"].ToString();
            SqlConnection con = new SqlConnection(connStr);

            SqlCommand cmd = new SqlCommand("SELECT * FROM dbo.upcomingMatchesOfClub(@ClubName)", con);
            string ClubName = GridView2.Rows[0].Cells[1].Text;
            cmd.Parameters.AddWithValue("@ClubName", ClubName);
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            
            GridView1.DataSource = dt;           
            GridView1.DataBind();
        }

        protected void sendRequest_Click(object sender, EventArgs e)
        {
            MultiView2.ActiveViewIndex = 3;
            this.BindGrid2();
            GridView3.DataBind();

        }

        private void BindGrid2()
        {

            string connStr = WebConfigurationManager.ConnectionStrings["MILESTONE"].ToString();
            SqlConnection con = new SqlConnection(connStr);

            SqlCommand cmd = new SqlCommand("SELECT DISTINCT * FROM dbo.upcomingMatchesOfClubStadiumNull(@ClubName)", con);
            string ClubName = GridView2.Rows[0].Cells[1].Text;
            cmd.Parameters.AddWithValue("@ClubName", ClubName);
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            GridView3.DataSource = dt;
            GridView3.DataBind();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            
            try
            {
                string ClubName = GridView2.Rows[0].Cells[1].Text;
                string Stadium = DropDownList1.SelectedItem.Value;
                DateTime starttime = Convert.ToDateTime((GridView3.SelectedRow.Cells[3]).Text);
                string connStr = WebConfigurationManager.ConnectionStrings["Milestone"].ToString();
                SqlConnection con = new SqlConnection(connStr);
                SqlCommand cmd = new SqlCommand("addHostRequest", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@hostclub_name", ClubName);
                cmd.Parameters.AddWithValue("@stadiumname", Stadium);
                cmd.Parameters.AddWithValue("@match_starttime", starttime);

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                GridView3.DataBind();

                Label1.Text = "Host Request Sent Succeessfully";

            }
            catch(Exception ex)
            {

                Label1.Text = ex.Message;

            }

           



        }

        protected void logout_Click(object sender, EventArgs e)
        {
            Response.Redirect("/FanLogin.aspx");
        }
    }
}