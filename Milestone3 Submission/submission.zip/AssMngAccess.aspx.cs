﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Milestone_Three
{
    public partial class AssMngAccess : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        protected void Button1_Click1(object sender, EventArgs e)
        {
            string host = DropDownList1.SelectedItem.Value;
            string guest = DropDownList2.SelectedItem.Value;
            DateTime starttime = Convert.ToDateTime(start.Text)  ;
            DateTime endtime = Convert.ToDateTime(end.Text);
            
            string connStr = WebConfigurationManager.ConnectionStrings["Milestone"].ToString();
            SqlConnection con = new SqlConnection(connStr);
            SqlCommand cmd = new SqlCommand("addnewMatch", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@host_club_name", host);
            cmd.Parameters.AddWithValue("@guest_club_name", guest);
            cmd.Parameters.AddWithValue("@start_time", starttime);
            cmd.Parameters.AddWithValue("@end_time", endtime);
            if (host.Equals(guest))
            {
               Label1.Text= "Host and Guest should be different";
            }
            else
            {
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                GridView1.DataBind();
                GridView3.DataBind();
                GridView4.DataBind();
                Label1.Text = "Match added";

            }


        }


        protected void Button2_Click(object sender, EventArgs e)
        {

            string host = deletehost.SelectedItem.Value;
            string guest = deleteguest.SelectedItem.Value;
            DateTime starttime = Convert.ToDateTime(deletestart.Text) ;
            DateTime endtime = Convert.ToDateTime(deleteend.Text) ;

            string connStr = WebConfigurationManager.ConnectionStrings["Milestone"].ToString();
            SqlConnection con = new SqlConnection(connStr);
            SqlCommand cmd = new SqlCommand("deleteMatch", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@host_club_name", host);
            cmd.Parameters.AddWithValue("@guest_club_name", guest);
            cmd.Parameters.AddWithValue("@start_time", starttime);
            cmd.Parameters.AddWithValue("@end_time", endtime);
            con.Open();

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                cmd.ExecuteNonQuery();
                GridView1.DataBind();
                GridView3.DataBind();
                GridView4.DataBind();
                Label2.Text = "Match deleted";

            }
            else
            {
                Label2.Text = "Match not found";

            }
            con.Close();

        }
        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            MultiView1.ActiveViewIndex = 0;
        }
        protected void upcoming_Click(object sender, EventArgs e)
        {
            MultiView1.ActiveViewIndex = 2;
            GridView1.DataBind();
            GridView3.DataBind();
            GridView4.DataBind();

        }
        protected void add_Click(object sender, EventArgs e)
        {
            MultiView1.ActiveViewIndex = 3;
            GridView1.DataBind();
            GridView3.DataBind();
            GridView4.DataBind();
        }
        protected void delete_Click(object sender, EventArgs e)
        {
            MultiView1.ActiveViewIndex = 4;
            GridView1.DataBind();
            GridView3.DataBind();
            GridView4.DataBind();

        }
        protected void played_Click(object sender, EventArgs e)
        {
            MultiView1.ActiveViewIndex = 1;
            GridView1.DataBind();
            GridView3.DataBind();
            GridView4.DataBind();
        }
        protected void home_Click(object sender, EventArgs e)
        {
            MultiView1.ActiveViewIndex = -1;
        }

        protected void logout_Click(object sender, EventArgs e)
        {
            Response.Redirect("/FanLogin.aspx");
        }
    }
}