﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml.Linq;
using static System.Net.Mime.MediaTypeNames;

namespace Milestone_Three
{
    public partial class FanAccess : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void SearchMatches_Click(object sender, EventArgs e)
        {
            /*          DateTime date = Convert.ToDateTime(TextBox1.Text);
                        string connStr = WebConfigurationManager.ConnectionStrings["MILESTONE"].ToString();
                        SqlConnection conn = new SqlConnection(connStr);
                        SqlCommand command = new SqlCommand("SELECT * FROM availableMatchesToAttend(@date)", conn);
                        command.Parameters.AddWithValue("@date", date);

                        conn.Open();

                        SqlDataReader rdr = command.ExecuteReader(System.Data.CommandBehavior.CloseConnection);
                        while (rdr.Read())
                        {
                            string host = rdr.GetString(rdr.GetOrdinal("hostClubName"));
                            string guest = rdr.GetString(rdr.GetOrdinal("competingClubName"));
                            DateTime time = rdr.GetDateTime(rdr.GetOrdinal("starttime"));
                            string stadium = rdr.GetString(rdr.GetOrdinal("stadiumName"));

                            TableRow row = new TableRow();
                            TableCell cell1 = new TableCell();
                            TableCell cell2 = new TableCell();
                            TableCell cell3 = new TableCell();
                            TableCell cell4 = new TableCell();

                            cell1.Text = host + " ";
                            cell2.Text = guest + " ";
                            cell3.Text = time + " ";
                            cell4.Text = stadium + " ";
                            row.Cells.Add(cell1);
                            row.Cells.Add(cell2);
                            row.Cells.Add(cell3);
                            row.Cells.Add(cell4);
                            Table1.Rows.Add(row);
                        }*/
          
            DateTime date = Convert.ToDateTime(TextBox1.Text);
            string connStr = WebConfigurationManager.ConnectionStrings["MILESTONE"].ToString();
            SqlConnection conn = new SqlConnection(connStr);
            SqlCommand command = new SqlCommand("SELECT DISTINCT * FROM availableMatchesToAttend2(@date)", conn);
            command.Parameters.AddWithValue("@date", date);
            conn.Open();


            SqlDataAdapter da2 = new SqlDataAdapter(command);
            DataTable dt2 = new DataTable();
            da2.Fill(dt2);

            GridView1.DataSource = dt2;
            GridView1.DataBind();








        }

        protected void home_Click(object sender, EventArgs e)
        {
            MultiView2.ActiveViewIndex = -1;
        }

        protected void AvailableMatch_Click(object sender, EventArgs e)
        {
            MultiView2.ActiveViewIndex = 1;
        }

        protected void purchaseTickets_Click(object sender, EventArgs e)
        {
            MultiView2.ActiveViewIndex = 0;
            /*            GridView1 hantalla3 upcoming matches   */

            DateTime date = DateTime.Now;

            string connStr = WebConfigurationManager.ConnectionStrings["MILESTONE"].ToString();
            SqlConnection con = new SqlConnection(connStr);

            

            SqlCommand cmd = new SqlCommand("SELECT DISTINCT * FROM dbo.availableMatchesToAttend(@date)", con);
            cmd.Parameters.AddWithValue("@date", date);


            con.Open();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            GridView2.DataSource = dt;
            GridView2.DataBind();

            con.Close();



        }

        protected void btSearch_Click(object sender, EventArgs e)
        {
            string connStr = WebConfigurationManager.ConnectionStrings["MILESTONE"].ToString();
            SqlConnection conn = new SqlConnection(connStr);

            string nationalID = TextBox2.Text;
            string host = GridView2.SelectedRow.Cells[1].Text;
            string guest = GridView2.SelectedRow.Cells[2].Text;
            DateTime time = Convert.ToDateTime(GridView2.SelectedRow.Cells[3].Text);

            SqlCommand ticPur = new SqlCommand("purchaseTicket", conn);

            ticPur.CommandType = System.Data.CommandType.StoredProcedure;

            ticPur.Parameters.Add(new SqlParameter("@nationalID", nationalID));
            ticPur.Parameters.Add(new SqlParameter("@host_club_name", host));
            ticPur.Parameters.Add(new SqlParameter("@guest_club_name", guest));
            ticPur.Parameters.Add(new SqlParameter("@start_time", time));

            conn.Open();
            ticPur.ExecuteNonQuery();
            conn.Close();

        }

        protected void logout_Click(object sender, EventArgs e)
        {
            Response.Redirect("/FanLogin.aspx");
        }
    }
}