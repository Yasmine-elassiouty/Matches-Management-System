﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Milestone_Three
{
    public partial class SystemAdmin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void addclub_Click(object sender, EventArgs e)
        {
            MultiView2.ActiveViewIndex = 0;
        }

        protected void Unnamed1_Click(object sender, EventArgs e)
        {

            string clubname = addclubname.Text;
            string loc = location.Text;

            string connStr = WebConfigurationManager.ConnectionStrings["Milestone"].ToString();
            SqlConnection con = new SqlConnection(connStr);
            SqlCommand cmd = new SqlCommand("addClub", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@club_name", clubname);
            cmd.Parameters.AddWithValue("@club_location", loc);

            SqlCommand addcommand = new SqlCommand("Select * from allClubs where clubname = @club_name" , con);
            addcommand.Parameters.AddWithValue("@club_name", clubname);
            SqlDataAdapter da2 = new SqlDataAdapter(addcommand);
            DataTable addcommandTable = new DataTable();
            da2.Fill(addcommandTable);
            if(addcommandTable.Rows.Count > 0)
            {
                lblErrorMsg.Text = "Club Name already used";

            }
            else
            {
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                lblErrorMsg.Text = "Club added successfully";

            }
        }

        protected void deleteclub_Click(object sender, EventArgs e)
        {
            DropDownList1.DataBind();
            string clubname = DropDownList1.SelectedItem.Value;
            
            string connStr = WebConfigurationManager.ConnectionStrings["Milestone"].ToString();
            SqlConnection con = new SqlConnection(connStr);
            SqlCommand cmd = new SqlCommand("deleteClub", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@club_name", clubname);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            lblErrorMsg2.Text = "Club deleted successfully";

            DropDownList1.DataBind();




        }

        protected void deleteclub_Click1(object sender, EventArgs e)
        {
            MultiView2.ActiveViewIndex = 1;
            DropDownList1.DataBind();


        }

        protected void addstadium_Click(object sender, EventArgs e)
        {
            MultiView2.ActiveViewIndex = 2;

        }

        protected void Unnamed3_Click(object sender, EventArgs e)
        {
            string sname = stadiumname.Text;
            string loc = stadiumlocation.Text;
            int scapacity = (int) Convert.ToInt64(capacity.Text);

            string connStr = WebConfigurationManager.ConnectionStrings["Milestone"].ToString();
            SqlConnection con = new SqlConnection(connStr);
            SqlCommand cmd = new SqlCommand("addStadium", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@stadium_name", sname);
            cmd.Parameters.AddWithValue("@location", loc);
            cmd.Parameters.AddWithValue("@capacity", scapacity);


            SqlCommand addcommand = new SqlCommand("Select * from allStadiums where stadiumname = @stadium_name", con);
            addcommand.Parameters.AddWithValue("@stadium_name", sname);
            SqlDataAdapter da2 = new SqlDataAdapter(addcommand);
            DataTable addcommandTable = new DataTable();
            da2.Fill(addcommandTable);
            if (addcommandTable.Rows.Count > 0)
            {
                lblErrorMsg3.Text = "Stadium Name already used";

            }
            else
            {
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                lblErrorMsg3.Text = "Stadium added successfully";


            }


           


        }

        protected void deletestadium_Click(object sender, EventArgs e)
        {
            MultiView2.ActiveViewIndex = 3;
            DropDownList2.DataBind();

        }

        protected void Unnamed4_Click(object sender, EventArgs e)
        {
            DropDownList2.DataBind();


            string sname = DropDownList2.SelectedItem.Value;

            string connStr = WebConfigurationManager.ConnectionStrings["Milestone"].ToString();
            SqlConnection con = new SqlConnection(connStr);
            SqlCommand cmd = new SqlCommand("deleteStadium", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@stadium_name", sname);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
           
            lblErrorMsg4.Text = "Stadium deleted successfully";
            DropDownList2.DataBind();



        }

        protected void blockfan_Click(object sender, EventArgs e)
        {
            MultiView2.ActiveViewIndex = 4;
            DropDownList3.DataBind();


        }

        protected void Unnamed5_Click(object sender, EventArgs e)
        {
            DropDownList3.DataBind();

            string id = DropDownList3.SelectedItem.Value;


            string connStr = WebConfigurationManager.ConnectionStrings["Milestone"].ToString();
            SqlConnection con = new SqlConnection(connStr);
            SqlCommand cmd = new SqlCommand("blockFan", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@fan_nationalid", id);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            lblErrorMsg5.Text = "Fan blocked successfully";

            DropDownList3.DataBind();

        }

        protected void Unnamed6_Click(object sender, EventArgs e)
        {
            DropDownList4.DataBind();
            string id = DropDownList4.SelectedItem.Value;


            string connStr = WebConfigurationManager.ConnectionStrings["Milestone"].ToString();
            SqlConnection con = new SqlConnection(connStr);
            SqlCommand cmd = new SqlCommand("unblockFan", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@national_id", id);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            lblErrorMsg6.Text = "Fan unblocked successfully";

            DropDownList4.DataBind();
        }

        protected void unblockfan_Click(object sender, EventArgs e)
        {
            MultiView2.ActiveViewIndex = 5;
            DropDownList4.DataBind();

        }

        protected void home_Click(object sender, EventArgs e)
        {
            MultiView2.ActiveViewIndex = -1;

        }

        protected void logout_Click(object sender, EventArgs e)
        {
            Response.Redirect("/FanLogIn.aspx");
        }
    }
}