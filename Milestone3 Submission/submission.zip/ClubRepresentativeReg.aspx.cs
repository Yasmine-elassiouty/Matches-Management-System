﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.Services.Description;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Milestone_Three
{
    public partial class ClubRepresentative : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnsubmit_Click(object sender, EventArgs e)
        {
            string UserName = txtuser.Text;
            string Password = txtpwd.Text;
            string Club = DropDownList1.SelectedItem.Value;
            string representative_name = txtREPname.Text;
            string connStr = WebConfigurationManager.ConnectionStrings["MILESTONE"].ToString();
            SqlConnection conn = new SqlConnection(connStr);

            SqlCommand cmd = new SqlCommand("addRepresentative", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Representative_name", representative_name);
            cmd.Parameters.AddWithValue("@club_name", Club);
            cmd.Parameters.AddWithValue("@username", UserName);
            cmd.Parameters.AddWithValue("@password", Password);
            conn.Open();

            /* Association Manager*/

            SqlCommand AssociationManagerCommand = new SqlCommand("Select * from allAssocManagers where UserName = @username", conn);
            AssociationManagerCommand.Parameters.AddWithValue("@username", UserName);
            SqlDataAdapter da = new SqlDataAdapter(AssociationManagerCommand);
            DataTable AssociatinManagerTable = new DataTable();
            da.Fill(AssociatinManagerTable);


            /*ClubRepresentative*/

            SqlCommand ClubRepresentativeCommand = new SqlCommand("Select * from allClubRepresentatives where UserName = @username", conn);
            ClubRepresentativeCommand.Parameters.AddWithValue("@username", UserName);
            SqlDataAdapter da2 = new SqlDataAdapter(AssociationManagerCommand);
            DataTable ClubRepresentativeTable = new DataTable();
            da2.Fill(ClubRepresentativeTable);

            /*System Admin*/

            SqlCommand SystemAdminCommand = new SqlCommand("Select * from allSystemAdmins where UserName = @username", conn);
            SystemAdminCommand.Parameters.AddWithValue("@username", UserName);
            SqlDataAdapter da3 = new SqlDataAdapter(SystemAdminCommand);
            DataTable SystemAdminTable = new DataTable();
            da3.Fill(SystemAdminTable);



            /* Stadium Manager*/

            SqlCommand StadiumManagerCommand = new SqlCommand("Select * from allStadiumManagers where UserName = @username", conn);
            StadiumManagerCommand.Parameters.AddWithValue("@username", UserName);
            SqlDataAdapter da4 = new SqlDataAdapter(StadiumManagerCommand);
            DataTable StadiumManagerTable = new DataTable();
            da4.Fill(StadiumManagerTable);


            /*Fan*/

            SqlCommand FanCommand = new SqlCommand("Select * from allFans where UserName = @username", conn);
            FanCommand.Parameters.AddWithValue("@username", UserName);
            SqlDataAdapter da5 = new SqlDataAdapter(StadiumManagerCommand);
            DataTable FanTable = new DataTable();
            da5.Fill(FanTable);




            if ((AssociatinManagerTable.Rows.Count > 0) || (ClubRepresentativeTable.Rows.Count > 0) || (SystemAdminTable.Rows.Count > 0) || (StadiumManagerTable.Rows.Count > 0) || (FanTable.Rows.Count > 0))
            {
                lblErrorMsg.Text = "username already registered";
            }

            else
            {
                cmd.ExecuteNonQuery();
            }
            conn.Close();

        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            Response.Redirect("/FanLogin.aspx");
        }
    }
}