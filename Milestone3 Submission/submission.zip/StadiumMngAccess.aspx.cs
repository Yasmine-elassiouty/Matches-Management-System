﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Linq;
using System.Net.NetworkInformation;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Milestone_Three
{
    public partial class StadiumMngAccess : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

      

        protected void Button1_Click(object sender, EventArgs e)
        {
            

            
                if (GridView2.SelectedRow.Cells[6].Text.Equals("Unhandled"))
                {
                    string host = GridView2.SelectedRow.Cells[2].Text;
                    string guest = GridView2.SelectedRow.Cells[3].Text;
                    string starttime = GridView2.SelectedRow.Cells[4].Text;
                    string username = Session["Username"].ToString();
               


                    string connStr = WebConfigurationManager.ConnectionStrings["Milestone"].ToString();
                    SqlConnection con = new SqlConnection(connStr);
                    SqlCommand cmd = new SqlCommand("acceptRequest", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@stadium_manager_username", username);
                    cmd.Parameters.AddWithValue("@host_club_name", host);
                    cmd.Parameters.AddWithValue("@guestclub_name", guest);
                    cmd.Parameters.AddWithValue("@match_starttime", starttime);

                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                    GridView2.DataBind();
            }
            else
            {
                Label1.Text="Can not accept an already handled request";
            }
        }

     

        protected void B_reject_hr_Click(object sender, EventArgs e)
        {

            try
            {
                if (GridView2.SelectedRow.Cells[6].Text.Equals("Unhandled"))
                {
                    string host = GridView2.SelectedRow.Cells[2].Text;
                    string guest = GridView2.SelectedRow.Cells[3].Text;
                    string starttime = GridView2.SelectedRow.Cells[4].Text;
                    string username = Session["Username"].ToString();



                    string connStr = WebConfigurationManager.ConnectionStrings["Milestone"].ToString();
                    SqlConnection con = new SqlConnection(connStr);
                    SqlCommand cmd = new SqlCommand("rejectRequest", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@stadium_manager_username", username);
                    cmd.Parameters.AddWithValue("@host_club_name", host);
                    cmd.Parameters.AddWithValue("@guest_club_name", guest);
                    cmd.Parameters.AddWithValue("@start_time", starttime);

                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                    GridView2.DataBind();
                }

                else if (GridView2.SelectedRow.Cells[6].Text.Equals("Unhandled") == false)
                {
                    Label1.Text="Can not reject an already handled request";
                }


            }

            catch(Exception ex) { 
            
                Response.Write(ex.ToString());
            }
















        }


        protected void homepgs_Click(object sender, EventArgs e)
        {
            MultiViewstd.ActiveViewIndex = -1;
        }

        protected void Stadium_Info_Click(object sender, EventArgs e)
        {
            MultiViewstd.ActiveViewIndex = 0;


        }

        protected void hostreq_Click(object sender, EventArgs e)
        {
            MultiViewstd.ActiveViewIndex = 1;

        }

        protected void Logout_Click(object sender, EventArgs e)
        {
            Response.Redirect("/FanLogin.aspx");
        }
    }
}

